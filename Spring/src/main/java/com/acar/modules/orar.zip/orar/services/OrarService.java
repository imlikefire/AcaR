package com.acar.modules.orar.services;

import com.acar.modules.orar.models.Orar;
import com.acar.services.CrudService;

public interface OrarService extends CrudService<Orar>{
}
