package com.acar.modules.orar.services;

import com.acar.modules.orar.models.Discipline;
import com.acar.services.CrudService;

public interface DisciplineService extends CrudService<Discipline> {
}