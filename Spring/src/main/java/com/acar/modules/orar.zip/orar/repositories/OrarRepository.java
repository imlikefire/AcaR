package com.acar.modules.orar.repositories;

import com.acar.modules.orar.models.Orar;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrarRepository extends JpaRepository<Orar, Long> {
    //
}

