package com.acar.modules.orar.services;


import com.acar.modules.orar.models.Profesori;
import com.acar.services.CrudService;

public interface ProfesoriService extends CrudService<Profesori> {
}
