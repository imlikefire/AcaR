package com.acar.modules.orar.repositories;

import com.acar.modules.orar.models.Profesori;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProfesoriRepository extends JpaRepository<Profesori, Long> {
    //
}
